import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def check_triangle(points):
    # Ensure we have exactly four points
    if len(points) != 4:
        return False

    # Extract the three points forming the triangle
    p1, p2, p3 = points[:3]

    # Convert points to NumPy arrays for vector operations
    p1 = np.array(p1)
    p2 = np.array(p2)
    p3 = np.array(p3)

    # Calculate the normal vector of the plane formed by the three points
    normal = np.cross(p2 - p1, p3 - p1)

    # Check if the fourth point lies on the plane
    if np.dot(normal, points[3] - p1) == 0:
        return True

    return False

def check_line(points):
    # Ensure we have exactly four points
    if len(points) != 4:
        return False

    # Calculate direction vectors
    direction_vectors = []
    for i in range(len(points) - 1):
        x_diff = points[i + 1][0] - points[i][0]
        y_diff = points[i + 1][1] - points[i][1]
        z_diff = points[i + 1][2] - points[i][2]
        direction_vectors.append((x_diff, y_diff, z_diff))

    # Check if direction vectors are collinear
    for i in range(len(direction_vectors) - 1):
        x_cross = direction_vectors[i][1] * direction_vectors[i + 1][2] - direction_vectors[i][2] * direction_vectors[i + 1][1]
        y_cross = direction_vectors[i][2] * direction_vectors[i + 1][0] - direction_vectors[i][0] * direction_vectors[i + 1][2]
        z_cross = direction_vectors[i][0] * direction_vectors[i + 1][1] - direction_vectors[i][1] * direction_vectors[i + 1][0]

        if x_cross != 0 or y_cross != 0 or z_cross != 0:
            return False

    return True

# Example usage
points_set1 = [(1, 1, 1), (1, 1, 2), (2, 1, 1), (1, 1, 1.5)]
points_set2 = [(1, 2, 3), (4, 5, 6), (7, 8, 9), (10, 11, 12)]

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot the points for set 1
x_set1 = [p[0] for p in points_set1]
y_set1 = [p[1] for p in points_set1]
z_set1 = [p[2] for p in points_set1]
ax.scatter(x_set1, y_set1, z_set1, c='red', label='Points Set 1')

# Plot the points for set 2
x_set2 = [p[0] for p in points_set2]
y_set2 = [p[1] for p in points_set2]
z_set2 = [p[2] for p in points_set2]
ax.scatter(x_set2, y_set2, z_set2, c='blue', label='Points Set 2')

plt.legend()
plt.show()

is_line_set1 = check_line(points_set1)
is_triangle_set1 = check_triangle(points_set1)

is_line_set2 = check_line(points_set2)
is_triangle_set2 = check_triangle(points_set2)

print("Set 1:")
if is_line_set1:
    print("The points form a line")
elif is_triangle_set1:
    print("The points form a triangle")
    # Calculate the area of the triangle
    p1, p2, p3 = points_set1[:3]
    matrix = np.vstack((p1, p2, p3))
    area = 0.5 * np.abs(np.linalg.det(matrix))
    print("Triangle Area:", area)
else:
    print("The points do not form a line or a triangle")

print("Set 2:")
if is_line_set2:
    print("The points form a line")
elif is_triangle_set2:
    print("The points form a triangle")
    # Calculate the area of the triangle
    p1, p2, p3 = points_set2[:3]
    matrix = np.vstack((p1, p2, p3))
    area = 0.5 * np.abs(np.linalg.det(matrix))
    print("Triangle Area:", area)
else:
    print("The points do not form a line or a triangle")