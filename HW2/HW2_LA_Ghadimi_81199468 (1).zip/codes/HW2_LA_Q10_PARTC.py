import numpy as np
import matplotlib.pyplot as plt

#describe matrix A
A = np.array([[0.9,0,0.03,0,0],
            [0.1,0.5,0,0,0],
            [0,0.5,0.47,0,0],
            [0,0,0.5,0.2,0],
            [0,0,0,0.8,0.1]])

x_t = np.array([[50,0,0,0,0]])
x_tn = np.zeros((5,1))
z = []
x_1 = []
x_2 = []
x_3 = []
x_4 = []
x_5 = []
x_out = []

for i in range(40) :
    x_tn = np.dot(A,x_t.transpose())
    z.append(x_tn.transpose())
    x_t = x_tn.transpose()
    x_out.append(0.9*(z[i][0][4]))
    out = sum(x_out)
    if out >= 0.9*50 :
        print("amount of drug that is out : ",out)
        # i+2 cuse we start from i = 0 and x_0 instead of x_1 and i = 1
        print("time : ",i+2)
        break
